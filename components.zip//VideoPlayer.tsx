import { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { Play, Pause, Volume2, VolumeX, Maximize, Settings, SkipBack, SkipForward } from 'lucide-react';
import { API_URL } from '../config';

interface VideoPlayerProps {
  videoId?: string;
  iframeUrl?: string | null;
  hlsUrl?: string | null;
  thumbnail?: string;
  title?: string;
  episode?: number;
  onNextEpisode?: () => void;
  onPrevEpisode?: () => void;
}

export function VideoPlayer({ 
  videoId, 
  iframeUrl, 
  hlsUrl, 
  thumbnail,
  title = 'Anime Episode',
  episode = 1,
  onNextEpisode,
  onPrevEpisode
}: VideoPlayerProps) {
  const [iframe, setIframe] = useState<string | null>(iframeUrl ?? null);
  const [hls, setHls] = useState<string | null>(hlsUrl ?? null);
  const [poster, setPoster] = useState<string | null>(thumbnail ?? null);
  const [loading, setLoading] = useState<boolean>(true);
  const [showControls, setShowControls] = useState(true);

  useEffect(() => {
    // If neither iframe nor hls provided, fetch episode details from our server
    if (!iframe && !hls && videoId) {
      fetch(`${API_URL}/api/episodes/${videoId}`)
        .then((r) => r.json())
        .then((data) => {
          if (data?.success && data.data) {
            setIframe(data.data.iframeUrl || null);
            setHls(data.data.hlsUrl || null);
            setPoster(data.data.thumbnail || null);
          }
        })
        .catch((err) => console.error('Failed to fetch episode:', err))
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [videoId, iframe, hls]);

  if (loading) {
    return (
      <div className="w-full aspect-video bg-black rounded-lg flex items-center justify-center">
        <div className="text-white">Loading player...</div>
      </div>
    );
  }

  // Prefer iframe (Bunny iframe is easiest — avoids CORS)
  if (iframe) {
    return (
      <div 
        className="relative w-full aspect-video bg-black rounded-lg overflow-hidden group"
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => setShowControls(false)}
      >
        <iframe
          src={iframe}
          title="Ishanime Player"
          className="w-full h-full"
          allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />

        {/* Episode Navigation Overlay */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: showControls ? 1 : 0, x: showControls ? 0 : 20 }}
          className="absolute right-4 top-1/2 -translate-y-1/2 space-y-3 z-10 pointer-events-none"
        >
          {onPrevEpisode && (
            <motion.button
              whileHover={{ scale: 1.1, x: -5 }}
              whileTap={{ scale: 0.95 }}
              onClick={onPrevEpisode}
              className="w-12 h-12 bg-black/70 backdrop-blur-sm rounded-lg flex items-center justify-center hover:bg-[#ff2e97]/80 transition-colors border border-white/10 pointer-events-auto"
            >
              <SkipBack className="w-5 h-5 text-white" />
            </motion.button>
          )}
          {onNextEpisode && (
            <motion.button
              whileHover={{ scale: 1.1, x: -5 }}
              whileTap={{ scale: 0.95 }}
              onClick={onNextEpisode}
              className="w-12 h-12 bg-black/70 backdrop-blur-sm rounded-lg flex items-center justify-center hover:bg-[#ff2e97]/80 transition-colors border border-white/10 pointer-events-auto"
            >
              <SkipForward className="w-5 h-5 text-white" />
            </motion.button>
          )}
        </motion.div>

        {/* Top Info Overlay */}
        <motion.div
          initial={{ opacity: 1 }}
          animate={{ opacity: showControls ? 1 : 0 }}
          transition={{ duration: 0.3 }}
          className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/90 to-transparent p-6 z-10"
        >
          <div>
            <h3 className="text-white mb-1">{title}</h3>
            <p className="text-[#bbbbbb] text-sm">Episode {episode}</p>
          </div>
        </motion.div>
      </div>
    );
  }

  // Fallback: display poster with message
  return (
    <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden">
      {poster && (
        <img src={poster} alt={title} className="w-full h-full object-cover" />
      )}
      <div className="absolute inset-0 flex items-center justify-center bg-black/50">
        <div className="text-center text-white">
          <p className="mb-2">Video player requires iframe or HLS URL</p>
          <p className="text-sm text-gray-400">Install hls.js for HLS playback support</p>
        </div>
      </div>
    </div>
  );
}
