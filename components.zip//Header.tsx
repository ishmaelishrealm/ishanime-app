import { Search, Menu, Bookmark, Bell } from 'lucide-react';
import { motion } from 'motion/react';
import logoImage from 'figma:asset/3f29fd070471109e1e0987cbcfa3eb6aefa46c23.png';

interface HeaderProps {
  onSearch?: (query: string) => void;
}

export function Header({ onSearch }: HeaderProps) {
  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 bg-[#0a0a0a]/95 backdrop-blur-md border-b border-white/10"
    >
      <div className="max-w-[1920px] mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <motion.div
          className="flex items-center gap-3"
          whileHover={{ scale: 1.05 }}
        >
          <img 
            src={logoImage} 
            alt="Ishanime Logo" 
            className="w-12 h-12 object-contain"
            style={{ mixBlendMode: 'normal' }}
          />
          <h1 className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff2e97] to-[#ff6ba9] uppercase tracking-wider text-glow-pink">
            Ishanime
          </h1>
        </motion.div>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <NavLink href="#" active>New</NavLink>
          <NavLink href="#">My Bookmarks</NavLink>
          <NavLink href="#">Popular</NavLink>
          <NavLink href="#">Spring</NavLink>
          <NavLink href="#">Random</NavLink>
        </nav>

        {/* Search & Actions */}
        <div className="flex items-center gap-4">
          <div className="relative hidden lg:block">
            <input
              type="text"
              placeholder="Search anime..."
              className="w-64 bg-[#151515] border border-white/10 rounded-lg px-4 py-2 pl-10 text-sm text-white placeholder:text-gray-500 focus:border-[#ff2e97] focus:outline-none transition-all"
              onChange={(e) => onSearch?.(e.target.value)}
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          </div>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="lg:hidden p-2 hover:bg-white/5 rounded-lg transition-colors"
          >
            <Search className="w-5 h-5 text-gray-400" />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors relative"
          >
            <Bell className="w-5 h-5 text-gray-400" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#ff2e97] rounded-full glow-pink-sm"></span>
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors"
          >
            <Bookmark className="w-5 h-5 text-gray-400" />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="md:hidden p-2 hover:bg-white/5 rounded-lg transition-colors"
          >
            <Menu className="w-5 h-5 text-gray-400" />
          </motion.button>
        </div>
      </div>
    </motion.header>
  );
}

function NavLink({ href, children, active }: { href: string; children: React.ReactNode; active?: boolean }) {
  return (
    <motion.a
      href={href}
      className={`relative text-sm transition-colors ${
        active ? 'text-white' : 'text-gray-400 hover:text-white'
      }`}
      whileHover={{ y: -2 }}
    >
      {children}
      {active && (
        <motion.div
          layoutId="activeNav"
          className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#ff2e97] glow-pink-sm"
        />
      )}
    </motion.a>
  );
}
