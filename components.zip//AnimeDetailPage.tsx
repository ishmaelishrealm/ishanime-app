import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Star, Calendar, Tv } from 'lucide-react';
import { VideoPlayer } from './VideoPlayer';
import { AnimeCard } from './AnimeCard';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { API_URL } from '../config';

interface Episode {
  id: string;
  title: string;
  fullTitle?: string;
  thumbnail?: string;
  iframeUrl?: string;
  hlsUrl?: string;
  publishedAt?: string;
}

interface Show {
  id: string;
  title: string;
  slug: string;
  coverUrl?: string;
  episodes: Episode[];
}

interface AnimeDetailPageProps {
  slug: string;
  onBack: () => void;
}

export function AnimeDetailPage({ slug, onBack }: AnimeDetailPageProps) {
  const [show, setShow] = useState<Show | null>(null);
  const [selectedEpisodeIndex, setSelectedEpisodeIndex] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!slug) return;
    
    setLoading(true);
    setError(null);
    
    fetch(`${API_URL}/api/shows/${slug}`)
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((data) => {
        if (data?.success && data.data) {
          setShow(data.data);
          // auto-select newest episode (first in array)
          setSelectedEpisodeIndex(0);
        } else {
          setError('Show not found');
        }
      })
      .catch(() => {
        // Backend not available - show demo mode message
        setError('Backend not available. Download the project to use real Bunny CDN streaming.');
      })
      .finally(() => setLoading(false));
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] pt-20 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="mb-4">Loading anime...</div>
          <div className="w-16 h-16 border-4 border-[#ff2e97] border-t-transparent rounded-full animate-spin mx-auto glow-pink"></div>
        </div>
      </div>
    );
  }

  if (error || !show) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] pt-20">
        <div className="max-w-[1920px] mx-auto px-6 py-4">
          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            whileHover={{ x: -5 }}
            onClick={onBack}
            className="flex items-center gap-2 text-[#bbbbbb] hover:text-white transition-colors mb-8"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Home</span>
          </motion.button>
          <div className="text-white text-center py-20 max-w-2xl mx-auto">
            <h2 className="mb-4">⚠️ {error || 'Show not found'}</h2>
            <p className="text-[#bbbbbb] mb-6">
              You're in demo mode. To watch real videos from Bunny CDN:
            </p>
            <div className="bg-[#151515] border border-[#ff2e97]/50 rounded-lg p-6 text-left">
              <ol className="space-y-3 text-sm text-gray-300">
                <li className="flex gap-3">
                  <span className="text-[#ff2e97] flex-shrink-0">1.</span>
                  <span>Download this project from Figma Make</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-[#ff2e97] flex-shrink-0">2.</span>
                  <span>Follow the setup guide in README.md or SETUP.md</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-[#ff2e97] flex-shrink-0">3.</span>
                  <span>Configure your Bunny CDN credentials in server/.env</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-[#ff2e97] flex-shrink-0">4.</span>
                  <span>Run the backend server and frontend locally</span>
                </li>
              </ol>
            </div>
            <button
              onClick={onBack}
              className="mt-6 px-6 py-3 bg-[#ff2e97] text-white rounded-lg hover:bg-[#ff4aa7] transition-colors"
            >
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  const selectedEpisode = show.episodes[selectedEpisodeIndex];

  const handleNextEpisode = () => {
    if (selectedEpisodeIndex < show.episodes.length - 1) {
      setSelectedEpisodeIndex(selectedEpisodeIndex + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevEpisode = () => {
    if (selectedEpisodeIndex > 0) {
      setSelectedEpisodeIndex(selectedEpisodeIndex - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] pt-20">
      {/* Back Button */}
      <div className="max-w-[1920px] mx-auto px-6 py-4">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          whileHover={{ x: -5 }}
          onClick={onBack}
          className="flex items-center gap-2 text-[#bbbbbb] hover:text-white transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Home</span>
        </motion.button>
      </div>

      {/* Hero Section with Background */}
      <div className="relative w-full h-[400px] overflow-hidden mb-8">
        <div className="absolute inset-0">
          <ImageWithFallback
            src={show.coverUrl || selectedEpisode?.thumbnail || ''}
            alt={show.title}
            className="w-full h-full object-cover blur-md scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/80 to-[#0a0a0a]/50" />
        </div>

        <div className="relative z-10 max-w-[1920px] mx-auto px-6 h-full flex items-end pb-8">
          <div className="flex gap-8 items-end">
            {/* Poster */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="hidden md:block"
            >
              <div className="w-60 aspect-[2/3] rounded-lg overflow-hidden border-2 border-[#ff2e97] glow-pink">
                <ImageWithFallback
                  src={show.coverUrl || selectedEpisode?.thumbnail || ''}
                  alt={show.title}
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>

            {/* Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="flex-1"
            >
              <h1 className="text-white mb-2" style={{ fontSize: '2.5rem', fontWeight: 800 }}>
                {show.title}
              </h1>

              <div className="flex flex-wrap items-center gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Tv className="w-5 h-5 text-[#bbbbbb]" />
                  <span className="text-[#bbbbbb]">{show.episodes.length} Episodes</span>
                </div>
                <span className="px-3 py-1 bg-[#39ff14]/20 text-[#39ff14] rounded text-sm border border-[#39ff14]/30">
                  HD
                </span>
                <span className="px-3 py-1 bg-[#ff2e97]/20 text-[#ff2e97] rounded text-sm border border-[#ff2e97]/30">
                  Streaming Now
                </span>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-[1920px] mx-auto px-6 pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Video Player & Episodes */}
          <div className="lg:col-span-2 space-y-8">
            {/* Video Player */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              {selectedEpisode && (
                <VideoPlayer
                  videoId={selectedEpisode.id}
                  iframeUrl={selectedEpisode.iframeUrl}
                  hlsUrl={selectedEpisode.hlsUrl}
                  thumbnail={selectedEpisode.thumbnail || show.coverUrl}
                  title={show.title}
                  episode={selectedEpisodeIndex + 1}
                  onNextEpisode={selectedEpisodeIndex < show.episodes.length - 1 ? handleNextEpisode : undefined}
                  onPrevEpisode={selectedEpisodeIndex > 0 ? handlePrevEpisode : undefined}
                />
              )}
            </motion.div>

            {/* Current Episode Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-[#151515] rounded-lg p-6 border border-white/10"
            >
              <h2 className="text-white mb-2">Now Playing</h2>
              <h3 className="text-[#ff2e97] mb-4">{selectedEpisode?.title}</h3>
              {selectedEpisode?.fullTitle && selectedEpisode.fullTitle !== selectedEpisode.title && (
                <p className="text-[#bbbbbb] text-sm">{selectedEpisode.fullTitle}</p>
              )}
            </motion.div>

            {/* Episodes List */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <h2 className="text-white mb-4">All Episodes</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {show.episodes.map((episode, index) => (
                  <motion.div
                    key={episode.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 + index * 0.02 }}
                    whileHover={{ scale: 1.02 }}
                    onClick={() => {
                      setSelectedEpisodeIndex(index);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`bg-[#151515] rounded-lg p-4 border transition-all cursor-pointer group ${
                      selectedEpisodeIndex === index
                        ? 'border-[#ff2e97] glow-pink-sm'
                        : 'border-white/10 hover:border-[#ff2e97]/50'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-16 h-16 rounded flex items-center justify-center transition-colors ${
                        selectedEpisodeIndex === index
                          ? 'bg-[#ff2e97]/20'
                          : 'bg-[#1a1a1a] group-hover:bg-[#ff2e97]/20'
                      }`}>
                        <span className="text-[#ff2e97]">{index + 1}</span>
                      </div>
                      <div className="flex-1">
                        <h4 className="text-white mb-1 line-clamp-1">{episode.title}</h4>
                        {episode.publishedAt && (
                          <div className="flex items-center gap-3 text-xs text-[#888888]">
                            <span>{new Date(episode.publishedAt).toLocaleDateString()}</span>
                          </div>
                        )}
                      </div>
                      <div className={`w-6 h-6 rounded-full border-2 transition-colors ${
                        selectedEpisodeIndex === index
                          ? 'border-[#ff2e97] bg-[#ff2e97]'
                          : 'border-white/20 group-hover:border-[#ff2e97]'
                      }`}>
                        {selectedEpisodeIndex === index && (
                          <div className="w-full h-full flex items-center justify-center">
                            <div className="w-2 h-2 bg-white rounded-full"></div>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Right Column - Info */}
          <div className="space-y-6">
            <div className="bg-[#151515] rounded-lg p-6 border border-white/10">
              <h2 className="text-white mb-4">About</h2>
              <div className="space-y-3 text-sm">
                <div>
                  <span className="text-[#888888]">Total Episodes:</span>
                  <span className="text-white ml-2">{show.episodes.length}</span>
                </div>
                <div>
                  <span className="text-[#888888]">Status:</span>
                  <span className="text-[#39ff14] ml-2">Available</span>
                </div>
                <div>
                  <span className="text-[#888888]">Quality:</span>
                  <span className="text-white ml-2">HD 1080p</span>
                </div>
              </div>
            </div>

            <div className="bg-[#151515] rounded-lg p-6 border border-white/10">
              <h2 className="text-white mb-4">Server Info</h2>
              <p className="text-[#bbbbbb] text-sm">
                Streaming from Bunny CDN for optimal playback quality and speed.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
