# Ishanime Backend Server

Express server that connects to Bunny CDN and provides API endpoints for the Ishanime frontend.

## Setup

1. Install dependencies:
```bash
cd server
npm install
```

2. Create `.env` file:
```bash
cp .env.example .env
```

3. Edit `.env` with your Bunny CDN credentials:
```env
PORT=13500
BUNNY_LIBRARY_ID=your_library_id
BUNNY_API_KEY=your_api_key
BUNNY_DELIVERY_DOMAIN=your_domain.b-cdn.net
```

## Running

Development mode with auto-reload:
```bash
npm run dev
```

Production mode:
```bash
npm start
```

## API Endpoints

### GET /api/shows
Returns all anime shows grouped from Bunny videos.

Example response:
```json
{
  "success": true,
  "data": [
    {
      "id": "demon-slayer",
      "title": "Demon Slayer",
      "slug": "demon-slayer",
      "coverUrl": "https://...",
      "episodes": [...],
      "latestEpisode": {...}
    }
  ]
}
```

### GET /api/shows/:slug
Returns a specific show by slug.

### GET /api/episodes/:id
Returns a specific episode by video ID (GUID).

### POST /api/webhook/bunny
Webhook endpoint for Bunny CDN notifications. Clears cache when new videos are added.

## How It Works

1. **Fetches videos** from Bunny Library API
2. **Parses titles** to group videos into shows/episodes
3. **Generates URLs** for thumbnails, iframe player, and HLS streams
4. **Caches results** for 30 seconds to reduce API calls
5. **Exposes clean JSON** endpoints for the frontend

## Title Parsing

The server groups videos by parsing titles like:
- `"Show Title - Episode 01"`
- `"Show Title Episode 1"`
- `"Show Title: Episode Title"`

Videos with the same show title are grouped together automatically.

## Testing

Test the endpoints directly:
```bash
# List all shows
curl http://localhost:13500/api/shows

# Get specific show
curl http://localhost:13500/api/shows/demon-slayer

# Get specific episode
curl http://localhost:13500/api/episodes/your-video-guid
```

## Security Notes

- **Never commit** `.env` file with real credentials
- In production, configure CORS to only allow your domain
- Add webhook secret validation for production
- Consider adding rate limiting
